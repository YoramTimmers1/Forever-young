for x in range(1,11 +1):
    print(x, "AM")
    import time
    time.sleep(1)
for y in range(12,24 +1):
    print(y, "PM")
    import time
    time.sleep(1)