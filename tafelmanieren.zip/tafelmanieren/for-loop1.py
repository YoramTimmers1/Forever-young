for x in range (6,61, +6):
    print(x)
    import time
    time.sleep(1)