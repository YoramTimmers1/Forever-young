for x in range(20,50, +2):
    print(x)
    import time
    time.sleep(1)